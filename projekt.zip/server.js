const express = require("express");
const bcrypt = require("bcryptjs");
const path = require("path");
const { jsonTools, loadJson } = require("./jsonTools");

const app = express();
const PORT = 3000;

// Static files
app.use(express.static(path.join(__dirname, "public")));

// Farben für Konsole
const gray = "\x1b[90m";
const lblue = "\x1b[94m";
const green = "\x1b[92m";
const yellow = "\x1b[93m";
const red = "\x1b[91m";
const reset = "\x1b[0m";

// Middleware für JSON-Parsing
app.use(express.json());

// Logger Middleware (Requests + Responses)
app.use((req, res, next) => {
  const now = new Date().toISOString();
  console.log(`${lblue}[${now}]${reset} ${req.method} ${gray}${req.path}${reset}`);

  if (Object.keys(req.query).length > 0) {
    console.log(`${yellow}  Query:${reset}`, req.query);
  }
  if (Object.keys(req.body).length > 0) {
    console.log(`${yellow}  Body:${reset}`, req.body);
  }

  // --- Response Tracking ---
  const originalJson = res.json;
  res.json = function (body) {
    console.log(`${green}  ➡️ Response (JSON):${reset}`, body);
    return originalJson.call(this, body);
  };

  const originalSend = res.send;
  res.send = function (body) {
    console.log(`${green}  ➡️ Response (raw):${reset}`, body);
    return originalSend.call(this, body);
  };

  next();
});

// Create user
app.post("/user/create", (req, res) => {
  const { username, passwd } = req.query;

  if (!username || !passwd) {
    return res.status(400).json({ success: false, error: "username and passwd are required" });
  }

  try {
    jsonTools("./data.json", (data) => {
      if (!Array.isArray(data.user)) {
        data.user = [];
      }
      if (data.user.find(u => u.username === username)) {
        throw new Error("User already exists");
      }

      const hash = bcrypt.hashSync(passwd, 10);
      data.user.push({ username, passwd: hash });
    });

    res.json({ success: true, message: "User created", username });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// Get user (without password)
app.get("/user/get", (req, res) => {
  const { username } = req.query;

  if (!username) {
    return res.status(400).json({ success: false, error: "username is required" });
  }

  try {
    const data = loadJson("./data.json");
    const user = data.user?.find(u => u.username === username);

    if (!user) {
      return res.status(404).json({ success: false, error: "User not found" });
    }

    res.json({ success: true, user: { username: user.username } });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// Update password (requires old password)
app.post("/user/update", (req, res) => {
  const { username, oldPasswd, newPasswd } = req.query;

  if (!username || !oldPasswd || !newPasswd) {
    return res.status(400).json({ success: false, error: "username, oldPasswd and newPasswd are required" });
  }

  try {
    let updated = false;

    jsonTools("./data.json", (data) => {
      if (!Array.isArray(data.user)) {
        data.user = [];
      }

      const user = data.user.find(u => u.username === username);
      if (!user) throw new Error("User not found");

      const ok = bcrypt.compareSync(oldPasswd, user.passwd);
      if (!ok) throw new Error("Old password is incorrect");

      user.passwd = bcrypt.hashSync(newPasswd, 10);
      updated = true;
    });

    if (updated) {
      res.json({ success: true, message: "Password updated", username });
    }
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// Delete user
app.delete("/user/delete", (req, res) => {
  const { username } = req.query;

  if (!username) {
    return res.status(400).json({ success: false, error: "username is required" });
  }

  try {
    let deleted = false;

    jsonTools("./data.json", (data) => {
      if (!Array.isArray(data.user)) {
        data.user = [];
      }

      const index = data.user.findIndex(u => u.username === username);
      if (index === -1) throw new Error("User not found");

      data.user.splice(index, 1);
      deleted = true;
    });

    if (deleted) {
      res.json({ success: true, message: "User deleted", username });
    }
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// Verify user login
app.get("/user/verify", (req, res) => {
  const { username, passwd } = req.query;

  if (!username || !passwd) {
    return res.status(400).json({ success: false, error: "username and passwd are required" });
  }

  try {
    const data = loadJson("./data.json");
    if (!Array.isArray(data.user)) {
      return res.status(404).json({ success: false, error: "No users found" });
    }

    const user = data.user.find(u => u.username === username);
    if (!user) {
      return res.status(404).json({ success: false, error: "User not found" });
    }

    const ok = bcrypt.compareSync(passwd, user.passwd);
    if (!ok) {
      return res.status(401).json({ success: false, error: "Password incorrect" });
    }

    res.json({ success: true, message: "Login successful", username });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.get("/home", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "home.html"));
});

app.get("/data/css", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "output.css"));
});

app.get("/data/js/multi/loginhomep1", (req, res) => {
  res.type("application/javascript");
  res.sendFile(path.join(__dirname, "public", "script.js"));
})

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

